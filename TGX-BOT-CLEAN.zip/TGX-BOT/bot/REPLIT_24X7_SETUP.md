# Replit 24/7 Deployment Guide

Paket ini disiapkan untuk berjalan 24/7 di Replit **Reserved VM Deployment**.

## Kenapa bukan Autoscale?
Autoscale bisa turun ke nol saat idle. Untuk bot Discord yang harus tetap online,
pakai Reserved VM Deployment.

## Langkah cepat
1. Upload project ini ke Replit.
2. Isi Secrets / .env:
   - TOKEN
   - CLIENT_ID
   - OWNER_ID
   - PORT=3000
3. Jalankan tes lokal:
   - npm install
   - npm run deploy
   - npm start
4. Buka menu Deployments / Publish.
5. Pilih **Reserved VM**.
6. Build command:
   - npm install
7. Run command:
   - npm start
8. App type:
   - Web server
9. Expose port:
   - 3000
10. Publish deployment.

## Endpoint monitoring
- `/` status ringkas
- `/healthz` health check JSON
- `/readyz` Discord ready state

## Catatan
- `npm start` memakai supervisor restart otomatis jika bot crash.
- Data JSON lokal cocok untuk awal, tetapi untuk deployment produksi lebih aman pindah ke database/storage.
