#!/usr/bin/env bash
set -u

BACKOFF_SECONDS=${BACKOFF_SECONDS:-5}
MAX_RESTARTS=${MAX_RESTARTS:-0}
COUNT=0

echo "[supervisor] starting discord bot with auto-restart"

while true; do
  node src/index.js
  EXIT_CODE=$?
  COUNT=$((COUNT + 1))

  echo "[supervisor] bot exited with code ${EXIT_CODE}"

  if [ "$EXIT_CODE" -eq 0 ]; then
    echo "[supervisor] clean exit detected, not restarting"
    exit 0
  fi

  if [ "$MAX_RESTARTS" -gt 0 ] && [ "$COUNT" -ge "$MAX_RESTARTS" ]; then
    echo "[supervisor] reached MAX_RESTARTS=${MAX_RESTARTS}, stopping"
    exit "$EXIT_CODE"
  fi

  echo "[supervisor] restarting in ${BACKOFF_SECONDS}s..."
  sleep "$BACKOFF_SECONDS"
done
