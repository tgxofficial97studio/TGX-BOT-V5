# Publish on Replit

This package is prepared for Replit as a standard Node.js web app plus Discord bot.

## First run in the workspace
1. Add Secrets or `.env` values: `TOKEN`, `CLIENT_ID`, `OWNER_ID`, optionally `GUILD_ID`.
2. Run `npm install`
3. Run `npm run deploy`
4. Run `npm start`
5. Open the web preview or visit `/healthz` and confirm it responds.

## Publish / Deploy
In Replit Deployments, use:
- Build command: `npm install`
- Run command: `npm start`
- Port: `3000`

If Replit still says there is nothing to publish, stop the app, run `npm start` once so the web server is detected, refresh the page, and choose a Deployment instead of the design-only publish flow.
