require('./loadEnv');
const fs = require('fs');
const path = require('path');
const { REST, Routes } = require('discord.js');

function walk(dir) {
  const entries = fs.readdirSync(dir, { withFileTypes: true });
  const files = [];
  for (const entry of entries) {
    const full = path.join(dir, entry.name);
    if (entry.isDirectory()) files.push(...walk(full));
    else if (entry.isFile() && entry.name.endsWith('.js')) files.push(full);
  }
  return files;
}

async function main() {
  if (!process.env.TOKEN || !process.env.CLIENT_ID) {
    throw new Error('TOKEN dan CLIENT_ID wajib diisi di file .env');
  }

  const commandFiles = walk(path.join(__dirname, 'commands'));
  const commands = commandFiles
    .map((file) => require(file))
    .filter((cmd) => cmd?.data)
    .map((cmd) => cmd.data.toJSON());

  const rest = new REST({ version: '10' }).setToken(process.env.TOKEN);

  if (process.env.GUILD_ID) {
    await rest.put(
      Routes.applicationGuildCommands(process.env.CLIENT_ID, process.env.GUILD_ID),
      { body: commands }
    );
    console.log(`Deployed ${commands.length} guild commands.`);
  } else {
    await rest.put(Routes.applicationCommands(process.env.CLIENT_ID), { body: commands });
    console.log(`Deployed ${commands.length} global commands.`);
  }
}

main().catch((error) => {
  console.error(error);
  process.exit(1);
});
