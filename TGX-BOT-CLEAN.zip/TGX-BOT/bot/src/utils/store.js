const fs = require('fs');
const path = require('path');

const dataDir = path.join(__dirname, '..', 'data');
if (!fs.existsSync(dataDir)) fs.mkdirSync(dataDir, { recursive: true });

function fileFor(name) {
  return path.join(dataDir, `${name}.json`);
}

function read(name, fallback = {}) {
  const file = fileFor(name);
  if (!fs.existsSync(file)) {
    write(name, fallback);
    return structuredCloneSafe(fallback);
  }
  try {
    const raw = fs.readFileSync(file, 'utf8');
    return raw ? JSON.parse(raw) : structuredCloneSafe(fallback);
  } catch {
    return structuredCloneSafe(fallback);
  }
}

function write(name, data) {
  const file = fileFor(name);
  const temp = `${file}.tmp`;
  fs.writeFileSync(temp, JSON.stringify(data, null, 2));
  fs.renameSync(temp, file);
  return data;
}

function update(name, fallback, mutator) {
  const current = read(name, fallback);
  const next = mutator(current) || current;
  write(name, next);
  return next;
}

function structuredCloneSafe(value) {
  return JSON.parse(JSON.stringify(value));
}

module.exports = { read, write, update };
