const {
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  EmbedBuilder,
  StringSelectMenuBuilder
} = require('discord.js');

const ACCENT = 0xff2f72;
const VERSION = 'V5.1.0';

const CATEGORY_META = {
  voice: { label: 'Voice Commands', emoji: '🔊', desc: 'Panel channel suara sementara' },
  member: { label: 'Member Commands', emoji: '👥', desc: 'Profil, level, economy, reward' },
  utility: { label: 'Utility Commands', emoji: '🛠️', desc: 'Info bot, server, user, avatar' },
  staff: { label: 'Staff Commands', emoji: '👑', desc: 'Moderasi dan konfigurasi server' },
  owner: { label: 'Owner Commands', emoji: '🛡️', desc: 'Kontrol khusus owner/bot' },
  config: { label: 'Config Commands', emoji: '⚙️', desc: 'Setup panel dan pengaturan' },
  tickets: { label: 'Ticket Commands', emoji: '🎫', desc: 'Buat dan kelola tiket' },
  fun: { label: 'Fun Commands', emoji: '🎮', desc: 'Command hiburan' },
  economy: { label: 'Economy Commands', emoji: '💰', desc: 'Uang virtual dan hadiah harian' },
  leveling: { label: 'Level Commands', emoji: '📈', desc: 'Rank, leaderboard, reward level' },
  moderation: { label: 'Moderation Commands', emoji: '🚨', desc: 'Ban, kick, warn, timeout, lock' },
  security: { label: 'Security Commands', emoji: '🛡️', desc: 'Blacklist dan keamanan' },
  giveaway: { label: 'Giveaway Commands', emoji: '🎉', desc: 'Giveaway server' },
  core: { label: 'Core Commands', emoji: '✨', desc: 'Command utama bot' }
};

const FALLBACK = {
  create: ['voice', 'Create Channel'], limit: ['voice', 'Set User Limit'], privacy: ['voice', 'Set Privacy'], waiting: ['voice', 'Waiting Room'], chat: ['voice', 'Text Channel'], trust: ['voice', 'Trust User'], untrust: ['voice', 'Untrust User'], invite: ['voice', 'Invite Link'], region: ['voice', 'Set Region'], block: ['voice', 'Block User'], unblock: ['voice', 'Unblock User'], claim: ['voice', 'Claim Channel'], transfer: ['voice', 'Transfer Owner'], delete: ['voice', 'Delete Channel'],
  profile: ['member', 'View Profile'], rank: ['member', 'View Rank'], balance: ['member', 'Check Balance'], daily: ['member', 'Daily Reward'], inventory: ['member', 'Your Items'], shop: ['member', 'Buy Items'], leaderboard: ['member', 'Top Users'], level: ['member', 'User Level'], rep: ['member', 'Reputation'],
  ping: ['utility', 'Bot Latency'], uptime: ['utility', 'Bot Uptime'], server: ['utility', 'Server Info'], serverinfo: ['utility', 'Server Info'], user: ['utility', 'User Info'], userinfo: ['utility', 'User Info'], avatar: ['utility', 'User Avatar'], support: ['utility', 'Get Support'], vote: ['utility', 'Vote Bot'], invitebot: ['utility', 'Invite Bot'], docs: ['utility', 'Documentation'],
  announce: ['staff', 'Announcement'], warn: ['staff', 'Warn User'], mute: ['staff', 'Mute User'], timeout: ['staff', 'Timeout User'], ban: ['staff', 'Ban User'], kick: ['staff', 'Kick User'], clear: ['staff', 'Clear Channel'], purge: ['staff', 'Clear Messages'], lock: ['staff', 'Lock Channel'], unlock: ['staff', 'Unlock Channel'], slowmode: ['staff', 'Slowmode'], logs: ['staff', 'View Logs'], prefix: ['staff', 'Set Prefix'],
  eval: ['owner', 'Execute Code'], shutdown: ['owner', 'Shutdown Bot'], restart: ['owner', 'Restart Bot'], reload: ['owner', 'Reload Commands'], backup: ['owner', 'Backup Data'], setprefix: ['owner', 'Set Prefix'],
  help: ['core', 'This Menu'], say: ['core', 'Send Message'], dm: ['core', 'Send DM'], embed: ['core', 'Embed Builder'], setactivity: ['core', 'Set Activity'],
  ticketpanel: ['tickets', 'Ticket Panel'], close: ['tickets', 'Close Ticket'], add: ['tickets', 'Add User'], remove: ['tickets', 'Remove User'], giveaway: ['giveaway', 'Giveaway'], blacklist: ['security', 'Blacklist User'], automod: ['config', 'AutoMod'], verifypanel: ['config', 'Verify Panel'], rolepanel: ['config', 'Role Panel'], memberformpanel: ['config', 'Member Form'], setautorole: ['config', 'Set Autorole'], setwelcome: ['config', 'Set Welcome'], setgoodbye: ['config', 'Set Goodbye'], setlogchannel: ['config', 'Set Log Channel'], setlevelupchannel: ['config', 'Set Level Channel'], setmemberformchannel: ['config', 'Set Form Channel'], eightball: ['fun', 'Magic 8 Ball'], ship: ['fun', 'Ship Users'], work: ['economy', 'Work Reward'], pay: ['economy', 'Pay User'], claimreward: ['leveling', 'Claim Reward'], levelrewards: ['leveling', 'Level Rewards'], warnings: ['moderation', 'User Warnings'], untimeout: ['moderation', 'Remove Timeout']
};

function getCategoryFor(commandName) {
  const key = String(commandName || '').toLowerCase();
  if (FALLBACK[key]) return FALLBACK[key];
  return ['utility', 'Command'];
}

function getCommands(client) {
  const names = client?.commands ? [...client.commands.keys()].sort() : [];
  const out = names.map((name) => {
    const [category, short] = getCategoryFor(name);
    const cmd = client.commands.get(name);
    const desc = cmd?.data?.description || short || 'Command bot';
    return { name, category, desc: desc.slice(0, 90) };
  });
  for (const [name, [category, desc]] of Object.entries(FALLBACK)) {
    if (!out.some((c) => c.name === name)) out.push({ name, category, desc });
  }
  return out.sort((a, b) => a.category.localeCompare(b.category) || a.name.localeCompare(b.name));
}

function categoriesFrom(commands) {
  const set = [...new Set(commands.map((c) => c.category))];
  const priority = ['voice', 'member', 'utility', 'staff', 'owner', 'config', 'tickets', 'economy', 'leveling', 'moderation', 'security', 'fun', 'giveaway', 'core'];
  return set.sort((a, b) => priority.indexOf(a) - priority.indexOf(b));
}

function buildEmbed(client, selected = 'home') {
  const commands = getCommands(client);
  const cats = categoriesFrom(commands);
  const botName = client?.user?.username || process.env.BOT_NAME || 'TGX Bot';
  const embed = new EmbedBuilder()
    .setColor(ACCENT)
    .setTitle(`${botName} Help Interface`)
    .setDescription('Klik kategori, lalu klik command yang ingin kamu pakai. Jika command butuh input, bot akan kasih contoh pemakaian.')
    .setThumbnail(client?.user?.displayAvatarURL?.({ size: 256 }) || null)
    .addFields(
      { name: '🟢 Status', value: 'Online', inline: true },
      { name: '⭐ Version', value: VERSION, inline: true },
      { name: '⏱️ Mode', value: '24/7 Active', inline: true }
    )
    .setFooter({ text: 'TGX Bot V5 • Interactive Help GUI' })
    .setTimestamp();

  if (selected === 'home') {
    for (const cat of cats.slice(0, 8)) {
      const meta = CATEGORY_META[cat] || CATEGORY_META.utility;
      const list = commands.filter((c) => c.category === cat).slice(0, 12).map((c) => `\`/${c.name}\``).join('  ');
      embed.addFields({ name: `${meta.emoji} ${meta.label}`, value: list || 'Belum ada command.' });
    }
    embed.addFields({ name: '✨ Need help?', value: 'Pilih kategori di bawah untuk menampilkan tombol command yang bisa diklik.' });
  } else {
    const meta = CATEGORY_META[selected] || CATEGORY_META.utility;
    const list = commands.filter((c) => c.category === selected);
    embed.setDescription(`${meta.emoji} **${meta.label}**\n${meta.desc}\n\nKlik tombol command di bawah.`);
    embed.addFields({ name: 'Command tersedia', value: list.map((c) => `**/${c.name}** — ${c.desc}`).join('\n').slice(0, 3900) || 'Belum ada command.' });
  }
  return embed;
}

function categoryRows(client) {
  const commands = getCommands(client);
  const cats = categoriesFrom(commands).slice(0, 24);
  const options = [
    { label: 'Home', value: 'home', emoji: '🏠', description: 'Tampilkan semua kategori' },
    ...cats.map((cat) => {
      const meta = CATEGORY_META[cat] || CATEGORY_META.utility;
      return { label: meta.label.slice(0, 100), value: cat, emoji: meta.emoji, description: meta.desc.slice(0, 100) };
    })
  ];
  const menu = new StringSelectMenuBuilder().setCustomId('tgxhelp:category').setPlaceholder('Pilih kategori command').addOptions(options);
  return [new ActionRowBuilder().addComponents(menu)];
}

function commandRows(client, selected = 'home') {
  const rows = categoryRows(client);
  if (selected === 'home') return rows;
  const commands = getCommands(client).filter((c) => c.category === selected).slice(0, 20);
  for (let i = 0; i < commands.length; i += 5) {
    rows.push(new ActionRowBuilder().addComponents(
      commands.slice(i, i + 5).map((c) => new ButtonBuilder().setCustomId(`tgxhelp:cmd:${c.name}`).setLabel(`/${c.name}`.slice(0, 80)).setStyle(ButtonStyle.Secondary))
    ));
  }
  return rows.slice(0, 5);
}

async function sendHelp(interaction, client, selected = 'home') {
  return interaction.reply({ embeds: [buildEmbed(client, selected)], components: commandRows(client, selected), ephemeral: false });
}

async function handleHelpComponent(interaction, client) {
  const id = String(interaction.customId || '');
  if (id === 'tgxhelp:category' && interaction.isStringSelectMenu()) {
    const selected = interaction.values?.[0] || 'home';
    await interaction.update({ embeds: [buildEmbed(client, selected)], components: commandRows(client, selected) });
    return true;
  }
  if (id.startsWith('tgxhelp:cmd:') && interaction.isButton()) {
    const name = id.split(':')[2];
    const command = client.commands.get(name);
    const desc = command?.data?.description || getCategoryFor(name)[1] || 'Command bot';
    await interaction.reply({ content: `✅ Command dipilih: **/${name}**\n${desc}\n\nKetik **/${name}** di chat Discord untuk menjalankan command ini.`, ephemeral: true });
    return true;
  }
  return false;
}

module.exports = { sendHelp, handleHelpComponent, buildEmbed, commandRows };
