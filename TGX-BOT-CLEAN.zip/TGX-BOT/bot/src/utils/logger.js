const { EmbedBuilder } = require('discord.js');
const { read } = require('./store');

async function sendLog(guild, title, fields = []) {
  if (!guild) return;
  const settings = read('settings', {});
  const config = settings[guild.id] || {};
  if (!config.logChannelId) return;
  const channel = guild.channels.cache.get(config.logChannelId);
  if (!channel || !channel.isTextBased()) return;
  const embed = new EmbedBuilder()
    .setColor(0xFEE75C)
    .setTitle(title)
    .addFields(fields)
    .setTimestamp();
  await channel.send({ embeds: [embed] }).catch(() => null);
}

module.exports = { sendLog };
