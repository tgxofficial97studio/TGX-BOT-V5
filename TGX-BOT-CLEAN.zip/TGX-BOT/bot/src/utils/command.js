function command(data, execute) {
  return { data, execute };
}

module.exports = { command };
