const DEFAULT_REWARDS = [
  { level: 5, coins: 500 },
  { level: 10, coins: 1200 },
  { level: 15, coins: 2200 },
  { level: 20, coins: 3500 },
  { level: 25, coins: 5000 },
  { level: 30, coins: 7000 }
];

function levelKey(guildId, userId) {
  return `${guildId}:${userId}`;
}

function normalizeLevelEntry(entry = {}) {
  return {
    xp: Number(entry.xp) || 0,
    level: Math.max(1, Number(entry.level) || 1),
    lastMessageAt: Number(entry.lastMessageAt) || 0,
    claimedRewards: Array.isArray(entry.claimedRewards) ? [...new Set(entry.claimedRewards.map((v) => Number(v)).filter(Boolean))] : []
  };
}

function getLevelEntry(db, guildId, userId) {
  const namespaced = db[levelKey(guildId, userId)];
  if (namespaced) return normalizeLevelEntry(namespaced);

  const legacy = db[userId];
  if (legacy) return normalizeLevelEntry(legacy);

  return normalizeLevelEntry();
}

function setLevelEntry(db, guildId, userId, entry) {
  db[levelKey(guildId, userId)] = normalizeLevelEntry(entry);
  return db[levelKey(guildId, userId)];
}

function xpNeededFor(level) {
  return Math.max(100, level * 100);
}

function progressBar(current, needed, size = 10) {
  const safeNeeded = Math.max(1, needed);
  const filled = Math.max(0, Math.min(size, Math.round((current / safeNeeded) * size)));
  return `${'█'.repeat(filled)}${'░'.repeat(size - filled)}`;
}

function getGuildLeaderboard(levelDb, guildId) {
  const prefix = `${guildId}:`;
  return Object.entries(levelDb)
    .filter(([key, value]) => key.startsWith(prefix) && value && typeof value === 'object')
    .map(([key, value]) => {
      const userId = key.slice(prefix.length);
      const data = normalizeLevelEntry(value);
      return [userId, data];
    })
    .sort((a, b) => (b[1].level * 100000 + b[1].xp) - (a[1].level * 100000 + a[1].xp));
}

function getClaimableRewards(levelEntry, rewards = DEFAULT_REWARDS) {
  const claimed = new Set((levelEntry.claimedRewards || []).map((v) => Number(v)));
  return rewards.filter((reward) => levelEntry.level >= reward.level && !claimed.has(reward.level));
}

module.exports = {
  DEFAULT_REWARDS,
  levelKey,
  normalizeLevelEntry,
  getLevelEntry,
  setLevelEntry,
  xpNeededFor,
  progressBar,
  getGuildLeaderboard,
  getClaimableRewards
};
