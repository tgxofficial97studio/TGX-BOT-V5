const fs = require('fs');
const path = require('path');

async function writeTranscript(channel) {
  const messages = await channel.messages.fetch({ limit: 100 });
  const ordered = [...messages.values()].sort((a, b) => a.createdTimestamp - b.createdTimestamp);
  const rows = ordered.map((m) => {
    const time = new Date(m.createdTimestamp).toLocaleString('id-ID');
    const content = escapeHtml(m.content || '[embed/attachment]');
    return `<div class="msg"><div class="meta">${time} - <b>${escapeHtml(m.author.tag)}</b></div><div>${content}</div></div>`;
  }).join('\n');
  const html = `<!doctype html><html><head><meta charset="utf-8"><title>Transcript</title><style>body{font-family:Arial;padding:20px;background:#111;color:#eee}.msg{border:1px solid #333;border-radius:10px;padding:12px;margin:10px 0;background:#1e1e1e}.meta{color:#aaa;margin-bottom:8px}</style></head><body><h1>Transcript ${escapeHtml(channel.name)}</h1>${rows}</body></html>`;
  const outDir = path.join(__dirname, '..', 'data', 'transcripts');
  fs.mkdirSync(outDir, { recursive: true });
  const filename = `${channel.id}-${Date.now()}.html`;
  const file = path.join(outDir, filename);
  fs.writeFileSync(file, html);
  return { path: file, filename };
}

function escapeHtml(str) {
  return String(str)
    .replaceAll('&', '&amp;')
    .replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;')
    .replaceAll('"', '&quot;');
}

module.exports = { writeTranscript };
