const { EmbedBuilder } = require('discord.js');

function baseEmbed(title, description) {
  return new EmbedBuilder()
    .setColor(0x5865F2)
    .setTitle(title)
    .setDescription(description)
    .setTimestamp();
}

function errorEmbed(text) {
  return baseEmbed('Terjadi Error', text).setColor(0xED4245);
}

function successEmbed(text) {
  return baseEmbed('Berhasil', text).setColor(0x57F287);
}

module.exports = { baseEmbed, errorEmbed, successEmbed };
