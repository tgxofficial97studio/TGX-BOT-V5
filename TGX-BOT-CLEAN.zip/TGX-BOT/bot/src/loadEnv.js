require('dotenv').config();

if (!process.env.TOKEN && process.env.DISCORD_TOKEN) {
  process.env.TOKEN = process.env.DISCORD_TOKEN;
}
if (!process.env.CLIENT_ID && process.env.DISCORD_CLIENT_ID) {
  process.env.CLIENT_ID = process.env.DISCORD_CLIENT_ID;
}
if (!process.env.OWNER_ID && process.env.DISCORD_OWNER_ID) {
  process.env.OWNER_ID = process.env.DISCORD_OWNER_ID;
}
if (!process.env.GUILD_ID && process.env.DISCORD_GUILD_ID) {
  process.env.GUILD_ID = process.env.DISCORD_GUILD_ID;
}
