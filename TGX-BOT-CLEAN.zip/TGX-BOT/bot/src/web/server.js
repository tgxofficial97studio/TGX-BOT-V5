const express = require('express');
const { read } = require('../utils/store');

module.exports = function startWeb(client) {
  const app = express();
  const port = Number(process.env.PORT || 3000);
  const bootTime = new Date();

  app.get('/', (_req, res) => {
    const levels = read('levels', {});
    const economy = read('economy', {});
    res.send(`
      <html><body style="font-family:Arial;background:#0f172a;color:#e2e8f0;padding:24px">
      <h1>Discord Premium Bot V4</h1>
      <p>Status: ${client?.isReady?.() ? 'Online' : 'Starting'}</p>
      <p>Guilds: ${client?.guilds?.cache?.size || 0}</p>
      <p>Users in level db: ${Object.keys(levels).length}</p>
      <p>Users in economy db: ${Object.keys(economy).length}</p>
      <p>Boot time: ${bootTime.toISOString()}</p>
      </body></html>
    `);
  });

  app.get('/healthz', (_req, res) => {
    res.status(200).json({
      ok: true,
      discordReady: client?.isReady?.() || false,
      guilds: client?.guilds?.cache?.size || 0,
      bootTime: bootTime.toISOString(),
      uptimeSeconds: process.uptime()
    });
  });

  app.get('/readyz', (_req, res) => {
    if (client?.isReady?.()) {
      return res.status(200).json({ ready: true });
    }
    return res.status(503).json({ ready: false });
  });

  app.listen(port, '0.0.0.0', () => {
    console.log(`Web server running on ${port}`);
  });
};
