const {
  PermissionFlagsBits,
  ChannelType,
  ModalBuilder,
  TextInputBuilder,
  TextInputStyle,
  ActionRowBuilder,
  EmbedBuilder
} = require('discord.js');
const { handleHelpComponent } = require('../utils/helpPanel');
const { errorEmbed } = require('../utils/embeds');
const { read, update } = require('../utils/store');
const { writeTranscript } = require('../utils/transcript');

module.exports = {
  name: 'interactionCreate',
  async execute(interaction, client) {
    if ((interaction.isButton() || interaction.isStringSelectMenu()) && String(interaction.customId || '').startsWith('tgxhelp:')) {
      const handled = await handleHelpComponent(interaction, client).catch((err) => {
        console.error('[TGX Help GUI]', err);
        return false;
      });
      if (handled) return;
    }
    if (interaction.isChatInputCommand()) {
      const blacklist = read('blacklist', { users: [] });
      if ((blacklist.users || []).includes(interaction.user.id)) {
        return interaction.reply({ content: 'Kamu diblacklist dari bot ini.', ephemeral: true });
      }
      const command = client.commands.get(interaction.commandName);
      if (!command) return;
      try {
        await command.execute(interaction, client);
      } catch (error) {
        console.error(error);
        const payload = { embeds: [errorEmbed('Command gagal dijalankan. Cek console atau coba lagi.')] };
        if (interaction.deferred || interaction.replied) await interaction.followUp({ ...payload, ephemeral: true }).catch(() => null);
        else await interaction.reply({ ...payload, ephemeral: true }).catch(() => null);
      }
      return;
    }

    if (interaction.isButton()) {
      const [action, value] = interaction.customId.split(':');
      if (action === 'verify') {
        const role = interaction.guild.roles.cache.get(value);
        if (!role) return interaction.reply({ content: 'Role verifikasi tidak ditemukan.', ephemeral: true });
        await interaction.member.roles.add(role).catch(() => null);
        return interaction.reply({ content: 'Kamu sudah terverifikasi.', ephemeral: true });
      }

      if (action === 'rr') {
        const role = interaction.guild.roles.cache.get(value);
        if (!role) return interaction.reply({ content: 'Role reaction tidak ditemukan.', ephemeral: true });
        const has = interaction.member.roles.cache.has(role.id);
        if (has) {
          await interaction.member.roles.remove(role).catch(() => null);
          return interaction.reply({ content: `Role ${role.name} dilepas.`, ephemeral: true });
        }
        await interaction.member.roles.add(role).catch(() => null);
        return interaction.reply({ content: `Role ${role.name} diberikan.`, ephemeral: true });
      }

      if (action === 'memberform' && value === 'start') {
        const modal = new ModalBuilder()
          .setCustomId('memberform:submit')
          .setTitle('Form Member Baru');

        const nicknameInput = new TextInputBuilder()
          .setCustomId('nickname')
          .setLabel('Nama panggilan')
          .setPlaceholder('Contoh: Baru / Dimas / Naya')
          .setStyle(TextInputStyle.Short)
          .setRequired(true)
          .setMaxLength(40);

        const ageInput = new TextInputBuilder()
          .setCustomId('age')
          .setLabel('Umur')
          .setPlaceholder('Contoh: 17')
          .setStyle(TextInputStyle.Short)
          .setRequired(true)
          .setMaxLength(10);

        const cityInput = new TextInputBuilder()
          .setCustomId('city')
          .setLabel('Domisili')
          .setPlaceholder('Contoh: Jayapura')
          .setStyle(TextInputStyle.Short)
          .setRequired(true)
          .setMaxLength(50);

        const purposeInput = new TextInputBuilder()
          .setCustomId('purpose')
          .setLabel('Tujuan join server')
          .setPlaceholder('Contoh: cari teman, belajar, main bareng')
          .setStyle(TextInputStyle.Paragraph)
          .setRequired(true)
          .setMaxLength(300);

        modal.addComponents(
          new ActionRowBuilder().addComponents(nicknameInput),
          new ActionRowBuilder().addComponents(ageInput),
          new ActionRowBuilder().addComponents(cityInput),
          new ActionRowBuilder().addComponents(purposeInput)
        );

        return interaction.showModal(modal);
      }

      if (action === 'ticket' && value === 'create') {
        const settings = read('settings', {});
        const cfg = settings[interaction.guild.id] || {};
        const categoryId = cfg.ticketCategoryId || null;
        const existing = interaction.guild.channels.cache.find(
          (ch) => ch.topic === `ticket-owner:${interaction.user.id}`
        );
        if (existing) return interaction.reply({ content: `Kamu sudah punya tiket: ${existing}`, ephemeral: true });
        const channel = await interaction.guild.channels.create({
          name: `ticket-${interaction.user.username}`.toLowerCase().replace(/[^a-z0-9-]/g, '').slice(0, 25),
          type: ChannelType.GuildText,
          parent: categoryId || undefined,
          topic: `ticket-owner:${interaction.user.id}`,
          permissionOverwrites: [
            { id: interaction.guild.id, deny: [PermissionFlagsBits.ViewChannel] },
            { id: interaction.user.id, allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ReadMessageHistory] },
            { id: client.user.id, allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ManageChannels, PermissionFlagsBits.ReadMessageHistory] }
          ]
        });
        await channel.send(`Halo ${interaction.user}, staff akan membantu kamu di sini.`);
        return interaction.reply({ content: `Tiket dibuat: ${channel}`, ephemeral: true });
      }

      if (action === 'ticket' && value === 'close') {
        if (!interaction.channel?.name?.startsWith('ticket-')) {
          return interaction.reply({ content: 'Tombol ini hanya untuk channel tiket.', ephemeral: true });
        }
        await interaction.deferReply({ ephemeral: true });
        const transcript = await writeTranscript(interaction.channel);
        await interaction.followUp({ content: `Transcript dibuat: ${transcript.filename}`, ephemeral: true });
        return interaction.channel.delete('Ticket closed').catch(() => null);
      }
    }

    if (interaction.isModalSubmit() && interaction.customId === 'memberform:submit') {
      const nickname = interaction.fields.getTextInputValue('nickname').trim();
      const age = interaction.fields.getTextInputValue('age').trim();
      const city = interaction.fields.getTextInputValue('city').trim();
      const purpose = interaction.fields.getTextInputValue('purpose').trim();
      const submittedAt = new Date().toISOString();

      update('memberforms', {}, (db) => {
        db[`${interaction.guild.id}:${interaction.user.id}`] = {
          userId: interaction.user.id,
          guildId: interaction.guild.id,
          nickname,
          age,
          city,
          purpose,
          submittedAt
        };
        return db;
      });

      const settings = read('settings', {});
      const cfg = settings[interaction.guild.id] || {};
      const targetChannel = cfg.memberFormChannelId
        ? interaction.guild.channels.cache.get(cfg.memberFormChannelId) || await interaction.guild.channels.fetch(cfg.memberFormChannelId).catch(() => null)
        : interaction.channel;

      if (targetChannel?.isTextBased()) {
        const embed = new EmbedBuilder()
          .setColor(0x57F287)
          .setTitle('Data Member Baru Masuk')
          .addFields(
            { name: 'Member', value: `${interaction.user} (${interaction.user.id})` },
            { name: 'Nama panggilan', value: nickname, inline: true },
            { name: 'Umur', value: age, inline: true },
            { name: 'Domisili', value: city, inline: true },
            { name: 'Tujuan join', value: purpose }
          )
          .setTimestamp(new Date(submittedAt));
        await targetChannel.send({ embeds: [embed] }).catch(() => null);
      }

      return interaction.reply({
        content: 'Data kamu berhasil dikirim. Terima kasih sudah menyelesaikan misi member baru.',
        ephemeral: true
      });
    }
  }
};
