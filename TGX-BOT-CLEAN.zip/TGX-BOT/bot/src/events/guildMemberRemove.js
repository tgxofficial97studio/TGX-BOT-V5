const { EmbedBuilder } = require('discord.js');
const { read } = require('../utils/store');

module.exports = {
  name: 'guildMemberRemove',
  async execute(member) {
    const settings = read('settings', {});
    const cfg = settings[member.guild.id] || {};
    if (!cfg.goodbyeChannelId) return;
    const channel = member.guild.channels.cache.get(cfg.goodbyeChannelId);
    if (!channel?.isTextBased()) return;
    const embed = new EmbedBuilder()
      .setColor(0xED4245)
      .setTitle('Goodbye')
      .setDescription(`**${member.user.tag}** keluar dari server.`)
      .setTimestamp();
    await channel.send({ embeds: [embed] }).catch(() => null);
  }
};
