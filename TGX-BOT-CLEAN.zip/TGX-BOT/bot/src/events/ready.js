module.exports = {
  name: 'ready',
  once: true,
  async execute(client) {
    console.log(`Logged in as ${client.user.tag}`);
    try {
      client.user.setActivity('/help | Premium V4');
    } catch (err) {
      console.error('Failed to set activity:', err);
    }
  }
};
