const { EmbedBuilder } = require('discord.js');
const { read } = require('../utils/store');

module.exports = {
  name: 'guildMemberAdd',
  async execute(member) {
    const settings = read('settings', {});
    const cfg = settings[member.guild.id] || {};

    if (cfg.autoRoleId) {
      await member.roles.add(cfg.autoRoleId).catch(() => null);
    }

    if (cfg.welcomeChannelId) {
      const channel = member.guild.channels.cache.get(cfg.welcomeChannelId);
      if (channel?.isTextBased()) {
        const embed = new EmbedBuilder()
          .setColor(0x57F287)
          .setTitle('Selamat Datang')
          .setDescription(`Halo ${member}, selamat datang di **${member.guild.name}**!`)
          .setThumbnail(member.user.displayAvatarURL())
          .setTimestamp();
        await channel.send({ embeds: [embed] }).catch(() => null);
      }
    }

    if (cfg.memberFormChannelId) {
      const formChannel = member.guild.channels.cache.get(cfg.memberFormChannelId);
      if (formChannel?.isTextBased()) {
        const { ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
        const row = new ActionRowBuilder().addComponents(
          new ButtonBuilder()
            .setCustomId('memberform:start')
            .setLabel('Isi Data Member Baru')
            .setStyle(ButtonStyle.Primary)
        );
        const embed = new EmbedBuilder()
          .setColor(0x5865F2)
          .setTitle('Misi Isi Data Member Baru')
          .setDescription(`Halo ${member}, selesaikan misi isi data dulu ya. Klik tombol di bawah untuk mengisi form singkat.`)
          .setFooter({ text: 'Setelah submit, data akan tersimpan untuk admin.' })
          .setTimestamp();
        await formChannel.send({ content: `${member}`, embeds: [embed], components: [row] }).catch(() => null);
      }
    }
  }
};
