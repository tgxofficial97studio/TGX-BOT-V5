const { read, update } = require('../utils/store');
const { getLevelEntry, setLevelEntry, xpNeededFor, getClaimableRewards } = require('../utils/leveling');

module.exports = {
  name: 'messageCreate',
  async execute(message) {
    if (!message.guild || message.author.bot) return;

    const settings = read('settings', {});
    const cfg = settings[message.guild.id] || {};

    if (cfg.antiLink && /(https?:\/\/|discord\.gg\/)/i.test(message.content)) {
      if (!message.member.permissions.has('ManageMessages')) {
        await message.delete().catch(() => null);
        await message.channel.send({ content: `${message.author}, link tidak diizinkan di server ini.` })
          .then((m) => setTimeout(() => m.delete().catch(() => null), 4000))
          .catch(() => null);
        return;
      }
    }

    if (cfg.antiSpam) {
      const spam = read('spam', {});
      const key = `${message.guild.id}:${message.author.id}`;
      const now = Date.now();
      const entry = spam[key] || { count: 0, last: now };
      entry.count = now - entry.last < 4000 ? entry.count + 1 : 1;
      entry.last = now;
      spam[key] = entry;
      require('../utils/store').write('spam', spam);
      if (entry.count >= 6 && !message.member.permissions.has('ManageMessages')) {
        await message.member.timeout(60_000, 'Anti spam V4').catch(() => null);
        await message.channel.send(`${message.author} kena timeout 1 menit karena spam.`).catch(() => null);
        entry.count = 0;
      }
    }

    update('economy', {}, (db) => {
      const user = db[message.author.id] || { wallet: 0, bank: 0, dailyAt: 0 };
      user.wallet += 2;
      db[message.author.id] = user;
      return db;
    });

    const now = Date.now();
    const xpCooldownMs = 15_000;
    const xpGain = 6 + Math.floor(Math.random() * 10);
    let leveledUpTo = null;
    let pendingRewards = [];

    update('levels', {}, (db) => {
      const user = getLevelEntry(db, message.guild.id, message.author.id);
      if (now - user.lastMessageAt < xpCooldownMs) {
        return db;
      }

      user.lastMessageAt = now;
      user.xp += xpGain;

      while (user.xp >= xpNeededFor(user.level)) {
        user.xp -= xpNeededFor(user.level);
        user.level += 1;
        leveledUpTo = user.level;
      }

      pendingRewards = getClaimableRewards(user);
      setLevelEntry(db, message.guild.id, message.author.id, user);
      return db;
    });

    if (leveledUpTo) {
      const rewardHint = pendingRewards.length
        ? `\n🎁 Kamu punya ${pendingRewards.length} reward level yang bisa di-claim dengan /claimreward.`
        : '';
      const announceChannel = cfg.levelUpChannelId
        ? message.guild.channels.cache.get(cfg.levelUpChannelId) || await message.guild.channels.fetch(cfg.levelUpChannelId).catch(() => null)
        : message.channel;
      if (announceChannel && announceChannel.isTextBased()) {
        await announceChannel.send(`🎉 ${message.author} naik ke level **${leveledUpTo}**!${rewardHint}`).catch(() => null);
      }
    }
  }
};
