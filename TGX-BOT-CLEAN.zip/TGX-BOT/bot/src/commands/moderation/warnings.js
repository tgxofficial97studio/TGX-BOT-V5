const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits } = require('discord.js');
const { read } = require('../../utils/store');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('warnings')
    .setDescription('Lihat warning user')
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers)
    .addUserOption((o) => o.setName('user').setDescription('Target').setRequired(true)),
  async execute(interaction) {
    const user = interaction.options.getUser('user');
    const warns = read('warns', {})[user.id] || [];
    const text = warns.length ? warns.map((w, i) => `${i + 1}. ${w.reason} — ${w.by}`).join('\n') : 'Belum ada warning.';
    const embed = new EmbedBuilder().setColor(0xFEE75C).setTitle(`Warnings ${user.tag}`).setDescription(text);
    await interaction.reply({ embeds: [embed], ephemeral: true });
  }
};
