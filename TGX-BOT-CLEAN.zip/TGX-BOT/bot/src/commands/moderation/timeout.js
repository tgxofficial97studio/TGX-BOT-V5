const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { sendLog } = require('../../utils/logger');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('timeout')
    .setDescription('Timeout member')
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers)
    .addUserOption((o) => o.setName('user').setDescription('Target').setRequired(true))
    .addIntegerOption((o) => o.setName('minutes').setDescription('Menit').setRequired(true).setMinValue(1).setMaxValue(10080))
    .addStringOption((o) => o.setName('reason').setDescription('Alasan')),
  async execute(interaction) {
    const member = interaction.options.getMember('user');
    const minutes = interaction.options.getInteger('minutes');
    const reason = interaction.options.getString('reason') || 'No reason';
    if (!member) return interaction.reply({ content: 'Member tidak ditemukan.', ephemeral: true });
    await member.timeout(minutes * 60_000, reason);
    await interaction.reply(`✅ ${member.user.tag} ditimeout ${minutes} menit.`);
    await sendLog(interaction.guild, 'Timeout', [{ name: 'User', value: member.user.tag }, { name: 'Durasi', value: `${minutes} menit` }, { name: 'Reason', value: reason }]);
  }
};
