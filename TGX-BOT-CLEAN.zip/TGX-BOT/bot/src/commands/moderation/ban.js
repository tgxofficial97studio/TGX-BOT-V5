const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { sendLog } = require('../../utils/logger');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('ban')
    .setDescription('Ban member')
    .setDefaultMemberPermissions(PermissionFlagsBits.BanMembers)
    .addUserOption((o) => o.setName('user').setDescription('Target').setRequired(true))
    .addStringOption((o) => o.setName('reason').setDescription('Alasan')),
  async execute(interaction) {
    const user = interaction.options.getUser('user');
    const reason = interaction.options.getString('reason') || 'No reason';
    await interaction.guild.members.ban(user.id, { reason });
    await interaction.reply(`✅ ${user.tag} diban.`);
    await sendLog(interaction.guild, 'Ban', [{ name: 'User', value: user.tag }, { name: 'Reason', value: reason }]);
  }
};
