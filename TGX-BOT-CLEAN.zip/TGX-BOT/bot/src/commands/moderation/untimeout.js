const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('untimeout')
    .setDescription('Lepas timeout member')
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers)
    .addUserOption((o) => o.setName('user').setDescription('Target').setRequired(true)),
  async execute(interaction) {
    const member = interaction.options.getMember('user');
    if (!member) return interaction.reply({ content: 'Member tidak ditemukan.', ephemeral: true });
    await member.timeout(null);
    await interaction.reply(`✅ Timeout ${member.user.tag} dilepas.`);
  }
};
