const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { sendLog } = require('../../utils/logger');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('kick')
    .setDescription('Kick member')
    .setDefaultMemberPermissions(PermissionFlagsBits.KickMembers)
    .addUserOption((o) => o.setName('user').setDescription('Target').setRequired(true))
    .addStringOption((o) => o.setName('reason').setDescription('Alasan')),
  async execute(interaction) {
    const member = interaction.options.getMember('user');
    const reason = interaction.options.getString('reason') || 'No reason';
    if (!member) return interaction.reply({ content: 'Member tidak ditemukan.', ephemeral: true });
    await member.kick(reason);
    await interaction.reply(`✅ ${member.user.tag} dikick.`);
    await sendLog(interaction.guild, 'Kick', [{ name: 'User', value: member.user.tag }, { name: 'Reason', value: reason }]);
  }
};
