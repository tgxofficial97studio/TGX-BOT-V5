const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { update } = require('../../utils/store');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('warn')
    .setDescription('Warn member')
    .setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers)
    .addUserOption((o) => o.setName('user').setDescription('Target').setRequired(true))
    .addStringOption((o) => o.setName('reason').setDescription('Alasan').setRequired(true)),
  async execute(interaction) {
    const user = interaction.options.getUser('user');
    const reason = interaction.options.getString('reason');
    update('warns', {}, (db) => {
      db[user.id] = db[user.id] || [];
      db[user.id].push({ reason, by: interaction.user.tag, at: Date.now() });
      return db;
    });
    await interaction.reply(`⚠️ ${user.tag} diwarn. Alasan: ${reason}`);
  }
};
