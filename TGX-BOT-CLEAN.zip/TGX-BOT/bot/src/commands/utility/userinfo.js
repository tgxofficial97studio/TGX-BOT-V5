const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('userinfo')
    .setDescription('Info user')
    .addUserOption((o) => o.setName('user').setDescription('User target')),
  async execute(interaction) {
    const member = interaction.options.getMember('user') || interaction.member;
    const embed = new EmbedBuilder()
      .setColor(0x5865F2)
      .setTitle(`Info ${member.user.tag}`)
      .setThumbnail(member.user.displayAvatarURL())
      .addFields(
        { name: 'ID', value: member.id, inline: true },
        { name: 'Created', value: `<t:${Math.floor(member.user.createdTimestamp / 1000)}:R>`, inline: true },
        { name: 'Joined', value: `<t:${Math.floor(member.joinedTimestamp / 1000)}:R>`, inline: true }
      );
    await interaction.reply({ embeds: [embed] });
  }
};
