const { SlashCommandBuilder } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('ship')
    .setDescription('Cocok-cocokan dua user')
    .addUserOption((o) => o.setName('user1').setDescription('User pertama').setRequired(true))
    .addUserOption((o) => o.setName('user2').setDescription('User kedua').setRequired(true)),
  async execute(interaction) {
    const a = interaction.options.getUser('user1');
    const b = interaction.options.getUser('user2');
    const score = Math.floor(Math.random() * 101);
    await interaction.reply(`💘 Kecocokan ${a} dan ${b}: **${score}%**`);
  }
};
