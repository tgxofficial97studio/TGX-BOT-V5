const { SlashCommandBuilder } = require('discord.js');

const answers = ['Iya', 'Tidak', 'Mungkin', 'Coba nanti', 'Kemungkinan besar iya', 'Kurang bagus'];

module.exports = {
  data: new SlashCommandBuilder()
    .setName('magic8ball')
    .setDescription('Tanya bola ajaib')
    .addStringOption((o) => o.setName('question').setDescription('Pertanyaan').setRequired(true)),
  async execute(interaction) {
    const question = interaction.options.getString('question');
    const answer = answers[Math.floor(Math.random() * answers.length)];
    await interaction.reply(`🎱 **${question}**\nJawaban: **${answer}**`);
  }
};
