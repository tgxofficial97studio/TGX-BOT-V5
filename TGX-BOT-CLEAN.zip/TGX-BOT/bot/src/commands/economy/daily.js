const { SlashCommandBuilder } = require('discord.js');
const { update, read } = require('../../utils/store');

module.exports = {
  data: new SlashCommandBuilder().setName('daily').setDescription('Ambil daily reward'),
  async execute(interaction) {
    const now = Date.now();
    const db = read('economy', {});
    const user = db[interaction.user.id] || { wallet: 0, bank: 0, dailyAt: 0 };
    const diff = now - (user.dailyAt || 0);
    if (diff < 86_400_000) {
      const left = Math.ceil((86_400_000 - diff) / 3_600_000);
      return interaction.reply({ content: `Tunggu sekitar ${left} jam lagi.`, ephemeral: true });
    }
    update('economy', {}, (data) => {
      const current = data[interaction.user.id] || { wallet: 0, bank: 0, dailyAt: 0 };
      current.wallet += 500;
      current.dailyAt = now;
      data[interaction.user.id] = current;
      return data;
    });
    await interaction.reply('✅ Kamu dapat **500** coin dari daily.');
  }
};
