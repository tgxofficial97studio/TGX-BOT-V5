const { SlashCommandBuilder } = require('discord.js');
const { update, read } = require('../../utils/store');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('pay')
    .setDescription('Transfer coin')
    .addUserOption((o) => o.setName('user').setDescription('Penerima').setRequired(true))
    .addIntegerOption((o) => o.setName('amount').setDescription('Jumlah').setRequired(true).setMinValue(1)),
  async execute(interaction) {
    const target = interaction.options.getUser('user');
    const amount = interaction.options.getInteger('amount');
    const db = read('economy', {});
    const me = db[interaction.user.id] || { wallet: 0, bank: 0, dailyAt: 0 };
    if (target.bot) return interaction.reply({ content: 'Tidak bisa transfer ke bot.', ephemeral: true });
    if (me.wallet < amount) return interaction.reply({ content: 'Saldo wallet tidak cukup.', ephemeral: true });
    update('economy', {}, (data) => {
      const sender = data[interaction.user.id] || { wallet: 0, bank: 0, dailyAt: 0 };
      const receiver = data[target.id] || { wallet: 0, bank: 0, dailyAt: 0 };
      sender.wallet -= amount;
      receiver.wallet += amount;
      data[interaction.user.id] = sender;
      data[target.id] = receiver;
      return data;
    });
    await interaction.reply(`✅ Transfer **${amount}** coin ke ${target}.`);
  }
};
