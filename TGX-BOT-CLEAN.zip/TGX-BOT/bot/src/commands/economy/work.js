const { SlashCommandBuilder } = require('discord.js');
const { update } = require('../../utils/store');

module.exports = {
  data: new SlashCommandBuilder().setName('work').setDescription('Kerja untuk dapat coin'),
  async execute(interaction) {
    const amount = 100 + Math.floor(Math.random() * 251);
    update('economy', {}, (db) => {
      const user = db[interaction.user.id] || { wallet: 0, bank: 0, dailyAt: 0 };
      user.wallet += amount;
      db[interaction.user.id] = user;
      return db;
    });
    await interaction.reply(`💼 Kamu kerja dan dapat **${amount}** coin.`);
  }
};
