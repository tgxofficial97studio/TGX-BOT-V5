const { SlashCommandBuilder } = require('discord.js');
const { read } = require('../../utils/store');

module.exports = {
  data: new SlashCommandBuilder().setName('balance').setDescription('Lihat saldo')
    .addUserOption((o) => o.setName('user').setDescription('User target')),
  async execute(interaction) {
    const user = interaction.options.getUser('user') || interaction.user;
    const db = read('economy', {});
    const data = db[user.id] || { wallet: 0, bank: 0 };
    await interaction.reply(`💰 ${user.tag}\nWallet: **${data.wallet}**\nBank: **${data.bank}**`);
  }
};
