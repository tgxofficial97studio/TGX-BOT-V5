const { SlashCommandBuilder, PermissionFlagsBits, ChannelType } = require('discord.js');
const { update } = require('../../utils/store');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('setmemberformchannel')
    .setDescription('Set channel untuk misi isi data member baru')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
    .addChannelOption((o) =>
      o
        .setName('channel')
        .setDescription('Channel panel isi data')
        .addChannelTypes(ChannelType.GuildText)
        .setRequired(true)
    ),
  async execute(interaction) {
    const channel = interaction.options.getChannel('channel');
    update('settings', {}, (db) => {
      db[interaction.guild.id] = {
        ...(db[interaction.guild.id] || {}),
        memberFormChannelId: channel.id
      };
      return db;
    });
    await interaction.reply({ content: `Channel misi isi data diatur ke ${channel}.`, ephemeral: true });
  }
};
