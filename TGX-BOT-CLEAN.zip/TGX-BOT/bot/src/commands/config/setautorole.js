const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { update } = require('../../utils/store');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('setautorole')
    .setDescription('Set auto role member baru')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageRoles)
    .addRoleOption((o) => o.setName('role').setDescription('Role').setRequired(true)),
  async execute(interaction) {
    const role = interaction.options.getRole('role');
    update('settings', {}, (db) => {
      db[interaction.guild.id] = db[interaction.guild.id] || {};
      db[interaction.guild.id].autoRoleId = role.id;
      return db;
    });
    await interaction.reply(`✅ Auto role diset ke ${role}.`);
  }
};
