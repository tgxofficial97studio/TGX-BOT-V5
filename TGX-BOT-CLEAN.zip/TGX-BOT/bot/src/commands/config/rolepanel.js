const { SlashCommandBuilder, PermissionFlagsBits, ActionRowBuilder, ButtonBuilder, ButtonStyle, EmbedBuilder } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('rolepanel')
    .setDescription('Kirim panel role button')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageRoles)
    .addRoleOption((o) => o.setName('role').setDescription('Role yang dibagikan').setRequired(true))
    .addStringOption((o) => o.setName('label').setDescription('Label tombol').setRequired(true)),
  async execute(interaction) {
    const role = interaction.options.getRole('role');
    const label = interaction.options.getString('label');
    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId(`rr:${role.id}`).setLabel(label).setStyle(ButtonStyle.Primary)
    );
    const embed = new EmbedBuilder().setColor(0x5865F2).setTitle('Reaction Role').setDescription('Klik tombol untuk toggle role.');
    await interaction.reply({ embeds: [embed], components: [row] });
  }
};
