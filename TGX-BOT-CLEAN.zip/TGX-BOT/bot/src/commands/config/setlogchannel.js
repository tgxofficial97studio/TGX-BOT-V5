const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { update } = require('../../utils/store');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('setlogchannel')
    .setDescription('Set channel log')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
    .addChannelOption((o) => o.setName('channel').setDescription('Channel').setRequired(true)),
  async execute(interaction) {
    const channel = interaction.options.getChannel('channel');
    update('settings', {}, (db) => {
      db[interaction.guild.id] = db[interaction.guild.id] || {};
      db[interaction.guild.id].logChannelId = channel.id;
      return db;
    });
    await interaction.reply(`✅ Log channel diset ke ${channel}.`);
  }
};
