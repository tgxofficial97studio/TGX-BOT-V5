const {
  SlashCommandBuilder,
  PermissionFlagsBits,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  EmbedBuilder
} = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('memberformpanel')
    .setDescription('Kirim panel misi isi data untuk member baru')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild),
  async execute(interaction) {
    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId('memberform:start')
        .setLabel('Isi Data Sekarang')
        .setStyle(ButtonStyle.Primary)
    );

    const embed = new EmbedBuilder()
      .setColor(0x5865F2)
      .setTitle('Misi Member Baru')
      .setDescription([
        'Halo member baru, silakan isi data singkat kamu.',
        '',
        'Data yang diminta:',
        '• Nama panggilan',
        '• Umur',
        '• Domisili',
        '• Tujuan join server'
      ].join('\n'))
      .setFooter({ text: 'Klik tombol di bawah untuk membuka form.' });

    await interaction.reply({ embeds: [embed], components: [row] });
  }
};
