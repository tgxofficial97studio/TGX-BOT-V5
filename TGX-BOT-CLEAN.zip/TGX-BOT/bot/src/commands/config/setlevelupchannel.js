const { SlashCommandBuilder, PermissionFlagsBits, ChannelType } = require('discord.js');
const { update } = require('../../utils/store');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('setlevelupchannel')
    .setDescription('Set channel announce level up')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
    .addChannelOption((o) =>
      o
        .setName('channel')
        .setDescription('Channel announce level up')
        .addChannelTypes(ChannelType.GuildText)
        .setRequired(true)
    ),
  async execute(interaction) {
    const channel = interaction.options.getChannel('channel');
    update('settings', {}, (db) => {
      db[interaction.guild.id] = db[interaction.guild.id] || {};
      db[interaction.guild.id].levelUpChannelId = channel.id;
      return db;
    });
    await interaction.reply(`✅ Channel announce level up diset ke ${channel}.`);
  }
};
