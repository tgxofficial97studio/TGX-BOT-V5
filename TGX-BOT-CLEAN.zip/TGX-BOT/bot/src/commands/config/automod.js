const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { update, read } = require('../../utils/store');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('automod')
    .setDescription('Atur anti-link dan anti-spam')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
    .addBooleanOption((o) => o.setName('antilink').setDescription('Aktif/nonaktif anti-link'))
    .addBooleanOption((o) => o.setName('antispam').setDescription('Aktif/nonaktif anti-spam')),
  async execute(interaction) {
    const antiLink = interaction.options.getBoolean('antilink');
    const antiSpam = interaction.options.getBoolean('antispam');
    update('settings', {}, (db) => {
      db[interaction.guild.id] = db[interaction.guild.id] || {};
      if (antiLink !== null) db[interaction.guild.id].antiLink = antiLink;
      if (antiSpam !== null) db[interaction.guild.id].antiSpam = antiSpam;
      return db;
    });
    const cfg = read('settings', {})[interaction.guild.id] || {};
    await interaction.reply(`✅ Anti-link: **${cfg.antiLink ? 'ON' : 'OFF'}**, Anti-spam: **${cfg.antiSpam ? 'ON' : 'OFF'}**`);
  }
};
