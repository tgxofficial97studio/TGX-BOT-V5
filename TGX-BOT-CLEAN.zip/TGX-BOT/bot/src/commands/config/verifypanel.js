const { SlashCommandBuilder, PermissionFlagsBits, ActionRowBuilder, ButtonBuilder, ButtonStyle, EmbedBuilder } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('verifypanel')
    .setDescription('Kirim panel verifikasi')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
    .addRoleOption((o) => o.setName('role').setDescription('Role verifikasi').setRequired(true)),
  async execute(interaction) {
    const role = interaction.options.getRole('role');
    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId(`verify:${role.id}`).setLabel('Verify').setStyle(ButtonStyle.Success)
    );
    const embed = new EmbedBuilder().setColor(0x57F287).setTitle('Verification').setDescription('Klik tombol untuk mengambil role verifikasi.');
    await interaction.reply({ embeds: [embed], components: [row] });
  }
};
