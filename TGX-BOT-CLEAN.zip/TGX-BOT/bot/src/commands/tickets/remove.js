const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('ticketremove')
    .setDescription('Hapus user dari ticket')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageChannels)
    .addUserOption((o) => o.setName('user').setDescription('User').setRequired(true)),
  async execute(interaction) {
    if (!interaction.channel.name.startsWith('ticket-')) return interaction.reply({ content: 'Bukan channel tiket.', ephemeral: true });
    const user = interaction.options.getUser('user');
    await interaction.channel.permissionOverwrites.delete(user.id).catch(() => null);
    await interaction.reply(`✅ ${user} dihapus dari tiket.`);
  }
};
