const { SlashCommandBuilder, PermissionFlagsBits, ActionRowBuilder, ButtonBuilder, ButtonStyle, EmbedBuilder } = require('discord.js');
const { update } = require('../../utils/store');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('ticketpanel')
    .setDescription('Kirim panel tiket')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageChannels)
    .addChannelOption((o) => o.setName('category').setDescription('Kategori tiket')),
  async execute(interaction) {
    const category = interaction.options.getChannel('category');
    update('settings', {}, (db) => {
      db[interaction.guild.id] = db[interaction.guild.id] || {};
      db[interaction.guild.id].ticketCategoryId = category?.id || null;
      return db;
    });
    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId('ticket:create').setLabel('Buat Ticket').setStyle(ButtonStyle.Primary)
    );
    const embed = new EmbedBuilder().setColor(0x5865F2).setTitle('Support Ticket').setDescription('Klik tombol di bawah untuk membuat tiket.');
    await interaction.reply({ embeds: [embed], components: [row] });
  }
};
