const { SlashCommandBuilder } = require('discord.js');
const { read } = require('../../utils/store');
const { getLevelEntry, progressBar, xpNeededFor } = require('../../utils/leveling');

module.exports = {
  data: new SlashCommandBuilder().setName('rank').setDescription('Lihat rank kamu')
    .addUserOption((o) => o.setName('user').setDescription('User target')),
  async execute(interaction) {
    const user = interaction.options.getUser('user') || interaction.user;
    const levels = read('levels', {});
    const data = getLevelEntry(levels, interaction.guild.id, user.id);
    const needed = xpNeededFor(data.level);
    const bar = progressBar(data.xp, needed);
    await interaction.reply(
      `🏆 ${user.tag}\nLevel: **${data.level}**\nXP: **${data.xp}**/**${needed}**\nProgress: ${bar}`
    );
  }
};
