const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { read, update } = require('../../utils/store');
const { DEFAULT_REWARDS, getClaimableRewards, getLevelEntry, setLevelEntry } = require('../../utils/leveling');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('claimreward')
    .setDescription('Claim reward dari level yang sudah terbuka')
    .addIntegerOption((o) =>
      o.setName('level').setDescription('Claim reward level tertentu').setMinValue(1)
    ),
  async execute(interaction) {
    const requestedLevel = interaction.options.getInteger('level');
    const levelsDb = read('levels', {});
    const levelData = getLevelEntry(levelsDb, interaction.guild.id, interaction.user.id);

    let rewards = getClaimableRewards(levelData, DEFAULT_REWARDS);
    if (requestedLevel) {
      rewards = rewards.filter((reward) => reward.level === requestedLevel);
      const exists = DEFAULT_REWARDS.some((reward) => reward.level === requestedLevel);
      if (!exists) {
        return interaction.reply({ content: 'Reward untuk level itu tidak ada.', ephemeral: true });
      }
    }

    if (!rewards.length) {
      return interaction.reply({ content: 'Belum ada reward level yang bisa kamu claim.', ephemeral: true });
    }

    const totalCoins = rewards.reduce((sum, reward) => sum + reward.coins, 0);

    update('economy', {}, (db) => {
      const user = db[interaction.user.id] || { wallet: 0, bank: 0, dailyAt: 0 };
      user.wallet += totalCoins;
      db[interaction.user.id] = user;
      return db;
    });

    update('levels', {}, (db) => {
      const current = getLevelEntry(db, interaction.guild.id, interaction.user.id);
      current.claimedRewards = [...new Set([...(current.claimedRewards || []), ...rewards.map((reward) => reward.level)])];
      setLevelEntry(db, interaction.guild.id, interaction.user.id, current);
      return db;
    });

    const embed = new EmbedBuilder()
      .setColor(0x57F287)
      .setTitle('Reward berhasil di-claim')
      .setDescription([
        `Total reward: **${totalCoins}** coin`,
        '',
        ...rewards.map((reward) => `• Level ${reward.level}: ${reward.coins} coin`)
      ].join('\n'));

    await interaction.reply({ embeds: [embed] });
  }
};
