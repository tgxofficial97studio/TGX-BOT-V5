const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { read } = require('../../utils/store');
const { getGuildLeaderboard } = require('../../utils/leveling');

module.exports = {
  data: new SlashCommandBuilder().setName('leaderboard').setDescription('Leaderboard leveling server ini'),
  async execute(interaction) {
    const levels = read('levels', {});
    const top = getGuildLeaderboard(levels, interaction.guild.id).slice(0, 10);
    const desc = top.length
      ? top.map(([id, d], i) => `${i + 1}. <@${id}> — Level ${d.level} (${d.xp} XP)`).join('\n')
      : 'Belum ada data leveling di server ini.';
    const embed = new EmbedBuilder()
      .setColor(0xFEE75C)
      .setTitle(`Leaderboard ${interaction.guild.name}`)
      .setDescription(desc);
    await interaction.reply({ embeds: [embed] });
  }
};
