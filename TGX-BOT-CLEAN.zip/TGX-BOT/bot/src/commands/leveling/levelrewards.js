const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { read } = require('../../utils/store');
const { DEFAULT_REWARDS, getLevelEntry } = require('../../utils/leveling');

module.exports = {
  data: new SlashCommandBuilder().setName('levelrewards').setDescription('Lihat daftar reward leveling'),
  async execute(interaction) {
    const levels = read('levels', {});
    const data = getLevelEntry(levels, interaction.guild.id, interaction.user.id);
    const claimed = new Set(data.claimedRewards || []);

    const lines = DEFAULT_REWARDS.map((reward) => {
      const status = claimed.has(reward.level)
        ? '✅ sudah claim'
        : data.level >= reward.level
          ? '🎁 bisa di-claim'
          : '🔒 belum terbuka';
      return `Level **${reward.level}** — **${reward.coins}** coin — ${status}`;
    });

    const embed = new EmbedBuilder()
      .setColor(0x57F287)
      .setTitle('Daftar Reward Level')
      .setDescription(lines.join('\n'))
      .setFooter({ text: 'Pakai /claimreward untuk mengambil reward yang sudah terbuka.' });

    await interaction.reply({ embeds: [embed], ephemeral: true });
  }
};
