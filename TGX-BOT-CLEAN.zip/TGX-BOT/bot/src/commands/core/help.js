const { SlashCommandBuilder } = require('discord.js');
const { sendHelp } = require('../../utils/helpPanel');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('help')
    .setDescription('Buka GUI help interaktif dengan tombol command'),
  async execute(interaction, client) {
    await sendHelp(interaction, client, 'home');
  }
};
