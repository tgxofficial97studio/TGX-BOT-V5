const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('dm')
    .setDescription('Kirim pesan privat ke user via bot (owner only)')
    .addUserOption((o) =>
      o.setName('user').setDescription('User tujuan').setRequired(true)
    )
    .addStringOption((o) =>
      o.setName('text').setDescription('Isi pesan').setRequired(true)
    )
    .addBooleanOption((o) =>
      o.setName('embed').setDescription('Kirim sebagai embed')
    )
    .addStringOption((o) =>
      o.setName('title').setDescription('Judul embed (jika embed=true)')
    )
    .addStringOption((o) =>
      o.setName('color').setDescription('Warna embed hex, mis. #5865F2')
    ),
  async execute(interaction) {
    if (interaction.user.id !== process.env.OWNER_ID) {
      return interaction.reply({
        content: 'Hanya owner bot yang bisa pakai command ini.',
        ephemeral: true,
      });
    }

    const user = interaction.options.getUser('user');
    const text = interaction.options.getString('text');
    const asEmbed = interaction.options.getBoolean('embed') ?? false;
    const title = interaction.options.getString('title');
    const colorInput = interaction.options.getString('color');

    if (user.bot) {
      return interaction.reply({
        content: 'Tidak bisa kirim DM ke bot.',
        ephemeral: true,
      });
    }

    await interaction.deferReply({ ephemeral: true });

    try {
      const payload = {};
      if (asEmbed) {
        const embed = new EmbedBuilder().setDescription(text);
        if (title) embed.setTitle(title);
        if (colorInput) {
          const hex = colorInput.replace('#', '');
          if (/^[0-9a-fA-F]{6}$/.test(hex)) embed.setColor(parseInt(hex, 16));
        }
        payload.embeds = [embed];
      } else {
        payload.content = text;
      }

      await user.send(payload);
      await interaction.editReply(`DM terkirim ke ${user.tag}.`);
    } catch (err) {
      console.error('dm failed:', err);
      const msg =
        err.code === 50007
          ? `${user.tag} tidak menerima DM dari bot (DM ditutup atau bot diblokir).`
          : `Gagal kirim DM: ${err.message}`;
      await interaction.editReply(msg);
    }
  },
};
