const {
  SlashCommandBuilder,
  EmbedBuilder,
  ChannelType,
  PermissionFlagsBits,
} = require('discord.js');

function parseColor(input) {
  if (!input) return null;
  const hex = input.replace('#', '');
  if (/^[0-9a-fA-F]{6}$/.test(hex)) return parseInt(hex, 16);
  return null;
}

function parseFields(raw) {
  if (!raw) return [];
  return raw
    .split('|')
    .map((chunk) => chunk.trim())
    .filter(Boolean)
    .map((chunk) => {
      const [name, ...rest] = chunk.split('::');
      const value = rest.join('::').trim();
      const inlineMatch = value.match(/^(.*?)(?::inline)?$/i);
      const isInline = /:inline$/i.test(value);
      const cleanValue = isInline ? inlineMatch[1].trim() : value;
      return {
        name: (name || '\u200B').trim().slice(0, 256),
        value: (cleanValue || '\u200B').slice(0, 1024),
        inline: isInline,
      };
    })
    .slice(0, 25);
}

module.exports = {
  data: new SlashCommandBuilder()
    .setName('embed')
    .setDescription('Bangun custom embed lengkap (owner only)')
    .addChannelOption((o) =>
      o
        .setName('channel')
        .setDescription('Channel tujuan (default: channel saat ini)')
        .addChannelTypes(
          ChannelType.GuildText,
          ChannelType.GuildAnnouncement,
          ChannelType.PublicThread,
          ChannelType.PrivateThread
        )
    )
    .addStringOption((o) => o.setName('title').setDescription('Judul'))
    .addStringOption((o) =>
      o.setName('description').setDescription('Isi utama embed')
    )
    .addStringOption((o) => o.setName('url').setDescription('URL untuk judul'))
    .addStringOption((o) => o.setName('color').setDescription('Hex color, mis. #5865F2'))
    .addStringOption((o) => o.setName('author').setDescription('Nama author'))
    .addStringOption((o) => o.setName('author_icon').setDescription('Icon author URL'))
    .addStringOption((o) => o.setName('thumbnail').setDescription('Thumbnail URL'))
    .addStringOption((o) => o.setName('image').setDescription('Image URL besar'))
    .addStringOption((o) => o.setName('footer').setDescription('Footer text'))
    .addStringOption((o) => o.setName('footer_icon').setDescription('Footer icon URL'))
    .addBooleanOption((o) =>
      o.setName('timestamp').setDescription('Tampilkan timestamp sekarang')
    )
    .addStringOption((o) =>
      o
        .setName('fields')
        .setDescription(
          'Format: name::value | name::value:inline | ... (maks 25 field)'
        )
    ),
  async execute(interaction) {
    if (interaction.user.id !== process.env.OWNER_ID) {
      return interaction.reply({
        content: 'Hanya owner bot yang bisa pakai command ini.',
        ephemeral: true,
      });
    }

    const channel =
      interaction.options.getChannel('channel') || interaction.channel;
    const title = interaction.options.getString('title');
    const description = interaction.options.getString('description');
    const url = interaction.options.getString('url');
    const color = parseColor(interaction.options.getString('color'));
    const author = interaction.options.getString('author');
    const authorIcon = interaction.options.getString('author_icon');
    const thumbnail = interaction.options.getString('thumbnail');
    const image = interaction.options.getString('image');
    const footer = interaction.options.getString('footer');
    const footerIcon = interaction.options.getString('footer_icon');
    const timestamp = interaction.options.getBoolean('timestamp') ?? false;
    const fields = parseFields(interaction.options.getString('fields'));

    if (!title && !description && !author && fields.length === 0 && !image) {
      return interaction.reply({
        content:
          'Embed kosong. Isi minimal salah satu: title, description, author, image, atau fields.',
        ephemeral: true,
      });
    }

    const me = channel.guild?.members?.me;
    if (me && channel.permissionsFor) {
      const perms = channel.permissionsFor(me);
      if (
        !perms?.has(PermissionFlagsBits.SendMessages) ||
        !perms?.has(PermissionFlagsBits.EmbedLinks)
      ) {
        return interaction.reply({
          content: `Bot tidak punya izin kirim embed di ${channel}.`,
          ephemeral: true,
        });
      }
    }

    const embed = new EmbedBuilder();
    if (title) embed.setTitle(title.slice(0, 256));
    if (description) embed.setDescription(description.slice(0, 4096));
    if (url && title) embed.setURL(url);
    if (color !== null) embed.setColor(color);
    if (author) embed.setAuthor({ name: author.slice(0, 256), iconURL: authorIcon || undefined });
    if (thumbnail) embed.setThumbnail(thumbnail);
    if (image) embed.setImage(image);
    if (footer) embed.setFooter({ text: footer.slice(0, 2048), iconURL: footerIcon || undefined });
    if (timestamp) embed.setTimestamp(new Date());
    if (fields.length) embed.addFields(fields);

    try {
      await channel.send({ embeds: [embed] });
      await interaction.reply({
        content: `Embed dikirim ke ${channel}.`,
        ephemeral: true,
      });
    } catch (err) {
      console.error('embed failed:', err);
      await interaction.reply({
        content: `Gagal kirim embed: ${err.message}`,
        ephemeral: true,
      });
    }
  },
};
