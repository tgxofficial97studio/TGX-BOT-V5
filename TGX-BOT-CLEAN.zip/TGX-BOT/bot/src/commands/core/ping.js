const { SlashCommandBuilder } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder().setName('ping').setDescription('Cek latency bot'),
  async execute(interaction, client) {
    await interaction.reply(`Pong! API latency: ${client.ws.ping}ms`);
  }
};
