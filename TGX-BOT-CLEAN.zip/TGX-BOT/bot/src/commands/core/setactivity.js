const { SlashCommandBuilder, ActivityType } = require('discord.js');

const TYPE_CHOICES = [
  { name: 'Playing', value: 'Playing' },
  { name: 'Watching', value: 'Watching' },
  { name: 'Listening', value: 'Listening' },
  { name: 'Competing', value: 'Competing' },
  { name: 'Streaming', value: 'Streaming' },
];

const STATUS_CHOICES = [
  { name: 'Online', value: 'online' },
  { name: 'Idle', value: 'idle' },
  { name: 'Do Not Disturb', value: 'dnd' },
  { name: 'Invisible', value: 'invisible' },
];

module.exports = {
  data: new SlashCommandBuilder()
    .setName('setactivity')
    .setDescription("Ubah status presence bot (owner only)")
    .addStringOption((o) =>
      o.setName('text').setDescription('Teks aktivitas yang ditampilkan').setRequired(true)
    )
    .addStringOption((o) =>
      o
        .setName('type')
        .setDescription('Tipe aktivitas')
        .addChoices(...TYPE_CHOICES)
    )
    .addStringOption((o) =>
      o
        .setName('status')
        .setDescription('Status presence bot')
        .addChoices(...STATUS_CHOICES)
    )
    .addStringOption((o) =>
      o
        .setName('url')
        .setDescription('URL Twitch/YouTube (hanya untuk Streaming)')
    ),
  async execute(interaction, client) {
    if (interaction.user.id !== process.env.OWNER_ID) {
      return interaction.reply({
        content: 'Hanya owner bot yang bisa pakai command ini.',
        ephemeral: true,
      });
    }

    const text = interaction.options.getString('text');
    const typeName = interaction.options.getString('type') || 'Playing';
    const status = interaction.options.getString('status') || 'online';
    const url = interaction.options.getString('url');

    const type = ActivityType[typeName];
    const activity = { name: text, type };
    if (typeName === 'Streaming' && url) activity.url = url;

    try {
      client.user.setPresence({ activities: [activity], status });
      await interaction.reply({
        content: `Activity diubah ke **${typeName} ${text}** (status: ${status}).`,
        ephemeral: true,
      });
    } catch (err) {
      console.error('setactivity failed:', err);
      await interaction.reply({
        content: `Gagal mengubah activity: ${err.message}`,
        ephemeral: true,
      });
    }
  },
};
