const {
  SlashCommandBuilder,
  EmbedBuilder,
  ChannelType,
  PermissionFlagsBits,
} = require('discord.js');

const PING_CHOICES = [
  { name: 'None', value: 'none' },
  { name: '@everyone', value: 'everyone' },
  { name: '@here', value: 'here' },
  { name: 'Role', value: 'role' },
];

module.exports = {
  data: new SlashCommandBuilder()
    .setName('announce')
    .setDescription('Posting pengumuman embed ke sebuah channel (owner only)')
    .addChannelOption((o) =>
      o
        .setName('channel')
        .setDescription('Channel tujuan')
        .addChannelTypes(ChannelType.GuildText, ChannelType.GuildAnnouncement)
        .setRequired(true)
    )
    .addStringOption((o) =>
      o.setName('title').setDescription('Judul pengumuman').setRequired(true)
    )
    .addStringOption((o) =>
      o.setName('message').setDescription('Isi pengumuman').setRequired(true)
    )
    .addStringOption((o) =>
      o
        .setName('ping')
        .setDescription('Mention yang dipakai di luar embed')
        .addChoices(...PING_CHOICES)
    )
    .addRoleOption((o) =>
      o.setName('role').setDescription('Role yang di-mention (jika ping=Role)')
    )
    .addStringOption((o) =>
      o.setName('color').setDescription('Warna embed hex, mis. #5865F2')
    )
    .addStringOption((o) =>
      o.setName('image').setDescription('URL gambar besar di embed')
    ),
  async execute(interaction) {
    if (interaction.user.id !== process.env.OWNER_ID) {
      return interaction.reply({
        content: 'Hanya owner bot yang bisa pakai command ini.',
        ephemeral: true,
      });
    }

    const channel = interaction.options.getChannel('channel');
    const title = interaction.options.getString('title');
    const message = interaction.options.getString('message');
    const ping = interaction.options.getString('ping') || 'none';
    const role = interaction.options.getRole('role');
    const colorInput = interaction.options.getString('color');
    const image = interaction.options.getString('image');

    const me = channel.guild?.members?.me;
    if (me && channel.permissionsFor) {
      const perms = channel.permissionsFor(me);
      if (
        !perms?.has(PermissionFlagsBits.SendMessages) ||
        !perms?.has(PermissionFlagsBits.EmbedLinks)
      ) {
        return interaction.reply({
          content: `Bot tidak punya izin kirim embed di ${channel}.`,
          ephemeral: true,
        });
      }
    }

    const embed = new EmbedBuilder()
      .setTitle(title)
      .setDescription(message)
      .setTimestamp(new Date())
      .setFooter({
        text: `Pengumuman oleh ${interaction.user.tag}`,
        iconURL: interaction.user.displayAvatarURL(),
      });

    if (colorInput) {
      const hex = colorInput.replace('#', '');
      if (/^[0-9a-fA-F]{6}$/.test(hex)) embed.setColor(parseInt(hex, 16));
    } else {
      embed.setColor(0x5865f2);
    }
    if (image) embed.setImage(image);

    let content;
    const allowedMentions = { parse: [], roles: [], users: [] };
    if (ping === 'everyone') {
      content = '@everyone';
      allowedMentions.parse = ['everyone'];
    } else if (ping === 'here') {
      content = '@here';
      allowedMentions.parse = ['everyone'];
    } else if (ping === 'role') {
      if (!role) {
        return interaction.reply({
          content: 'Pilih role saat ping=Role.',
          ephemeral: true,
        });
      }
      content = `<@&${role.id}>`;
      allowedMentions.roles = [role.id];
    }

    try {
      await channel.send({
        content,
        embeds: [embed],
        allowedMentions,
      });
      await interaction.reply({
        content: `Pengumuman dikirim ke ${channel}.`,
        ephemeral: true,
      });
    } catch (err) {
      console.error('announce failed:', err);
      await interaction.reply({
        content: `Gagal kirim pengumuman: ${err.message}`,
        ephemeral: true,
      });
    }
  },
};
