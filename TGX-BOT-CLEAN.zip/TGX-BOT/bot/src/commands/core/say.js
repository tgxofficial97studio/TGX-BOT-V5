const {
  SlashCommandBuilder,
  EmbedBuilder,
  ChannelType,
  PermissionFlagsBits,
} = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('say')
    .setDescription('Kirim pesan atau embed atas nama bot (owner only)')
    .addStringOption((o) =>
      o.setName('text').setDescription('Isi pesan').setRequired(true)
    )
    .addChannelOption((o) =>
      o
        .setName('channel')
        .setDescription('Channel tujuan (default: channel saat ini)')
        .addChannelTypes(
          ChannelType.GuildText,
          ChannelType.GuildAnnouncement,
          ChannelType.PublicThread,
          ChannelType.PrivateThread
        )
    )
    .addBooleanOption((o) =>
      o.setName('embed').setDescription('Kirim sebagai embed')
    )
    .addStringOption((o) =>
      o.setName('title').setDescription('Judul embed (jika embed=true)')
    )
    .addStringOption((o) =>
      o.setName('color').setDescription('Warna embed hex, mis. #5865F2')
    ),
  async execute(interaction) {
    if (interaction.user.id !== process.env.OWNER_ID) {
      return interaction.reply({
        content: 'Hanya owner bot yang bisa pakai command ini.',
        ephemeral: true,
      });
    }

    const text = interaction.options.getString('text');
    const channel = interaction.options.getChannel('channel') || interaction.channel;
    const asEmbed = interaction.options.getBoolean('embed') ?? false;
    const title = interaction.options.getString('title');
    const colorInput = interaction.options.getString('color');

    if (!channel?.isTextBased?.()) {
      return interaction.reply({
        content: 'Channel tidak valid.',
        ephemeral: true,
      });
    }

    const me = channel.guild?.members?.me;
    if (me && channel.permissionsFor) {
      const perms = channel.permissionsFor(me);
      if (!perms?.has(PermissionFlagsBits.SendMessages)) {
        return interaction.reply({
          content: `Bot tidak punya izin kirim pesan di ${channel}.`,
          ephemeral: true,
        });
      }
    }

    try {
      if (asEmbed) {
        const embed = new EmbedBuilder().setDescription(text);
        if (title) embed.setTitle(title);
        if (colorInput) {
          const hex = colorInput.replace('#', '');
          if (/^[0-9a-fA-F]{6}$/.test(hex)) embed.setColor(parseInt(hex, 16));
        }
        await channel.send({ embeds: [embed] });
      } else {
        await channel.send({ content: text });
      }

      await interaction.reply({
        content: `Pesan terkirim ke ${channel}.`,
        ephemeral: true,
      });
    } catch (err) {
      console.error('say failed:', err);
      await interaction.reply({
        content: `Gagal kirim pesan: ${err.message}`,
        ephemeral: true,
      });
    }
  },
};
