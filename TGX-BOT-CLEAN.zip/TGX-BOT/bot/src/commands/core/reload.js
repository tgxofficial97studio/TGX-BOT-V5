const path = require('path');
const { SlashCommandBuilder } = require('discord.js');
const loadCommands = require('../../handlers/loadCommands');

function clearCommandCache() {
  const commandRoot = path.join(__dirname, '..');
  for (const key of Object.keys(require.cache)) {
    if (key.startsWith(commandRoot) && !key.endsWith(path.join('core', 'reload.js'))) {
      delete require.cache[key];
    }
  }
}

module.exports = {
  data: new SlashCommandBuilder()
    .setName('reload')
    .setDescription('Reload semua command file tanpa restart bot (owner only)'),
  async execute(interaction, client) {
    if (interaction.user.id !== process.env.OWNER_ID) {
      return interaction.reply({
        content: 'Hanya owner bot yang bisa pakai command ini.',
        ephemeral: true,
      });
    }

    await interaction.deferReply({ ephemeral: true });

    try {
      clearCommandCache();
      const commands = loadCommands(client);
      await interaction.editReply(`Reloaded ${commands.size} command files.`);
    } catch (err) {
      console.error('Reload failed:', err);
      await interaction.editReply(`Reload gagal: ${err.message}`);
    }
  },
};
