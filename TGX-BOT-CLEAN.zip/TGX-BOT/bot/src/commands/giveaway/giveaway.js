const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { update, read } = require('../../utils/store');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('giveaway')
    .setDescription('Start, end, atau reroll giveaway')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
    .addSubcommand((s) => s.setName('start').setDescription('Mulai giveaway')
      .addStringOption((o) => o.setName('prize').setDescription('Hadiah').setRequired(true))
      .addIntegerOption((o) => o.setName('minutes').setDescription('Durasi menit').setRequired(true).setMinValue(1).setMaxValue(10080))
      .addIntegerOption((o) => o.setName('winners').setDescription('Jumlah pemenang').setRequired(true).setMinValue(1).setMaxValue(20)))
    .addSubcommand((s) => s.setName('end').setDescription('Akhiri giveaway')
      .addStringOption((o) => o.setName('messageid').setDescription('ID pesan giveaway').setRequired(true)))
    .addSubcommand((s) => s.setName('reroll').setDescription('Reroll giveaway')
      .addStringOption((o) => o.setName('messageid').setDescription('ID pesan giveaway').setRequired(true))),
  async execute(interaction) {
    const sub = interaction.options.getSubcommand();
    if (sub === 'start') {
      const prize = interaction.options.getString('prize');
      const minutes = interaction.options.getInteger('minutes');
      const winners = interaction.options.getInteger('winners');
      const endAt = Date.now() + minutes * 60_000;
      const msg = await interaction.reply({ fetchReply: true, content: `🎉 **GIVEAWAY** 🎉\nHadiah: **${prize}**\nPemenang: **${winners}**\nBerakhir: <t:${Math.floor(endAt / 1000)}:R>\nReact dengan 🎉 untuk ikut!` });
      await msg.react('🎉');
      update('giveaways', {}, (db) => {
        db[msg.id] = { channelId: msg.channel.id, guildId: interaction.guild.id, prize, winners, endAt, ended: false };
        return db;
      });
      return;
    }

    const messageId = interaction.options.getString('messageid');
    const data = read('giveaways', {})[messageId];
    if (!data) return interaction.reply({ content: 'Data giveaway tidak ditemukan.', ephemeral: true });
    const channel = interaction.guild.channels.cache.get(data.channelId);
    const msg = await channel.messages.fetch(messageId).catch(() => null);
    if (!msg) return interaction.reply({ content: 'Pesan giveaway tidak ditemukan.', ephemeral: true });
    const reaction = msg.reactions.cache.get('🎉');
    const users = reaction ? (await reaction.users.fetch()).filter((u) => !u.bot) : new Map();
    const pool = [...users.values()];
    if (!pool.length) return interaction.reply('Tidak ada peserta valid.');
    const picked = [];
    while (picked.length < Math.min(data.winners, pool.length)) {
      const index = Math.floor(Math.random() * pool.length);
      picked.push(pool.splice(index, 1)[0]);
    }
    if (sub === 'end') {
      update('giveaways', {}, (db) => { if (db[messageId]) db[messageId].ended = true; return db; });
      await interaction.reply(`🏆 Pemenang giveaway **${data.prize}**: ${picked.map((u) => `${u}`).join(', ')}`);
      await msg.reply(`🏆 Giveaway berakhir. Pemenang: ${picked.map((u) => `${u}`).join(', ')}`);
      return;
    }
    await interaction.reply(`🔄 Reroll winner: ${picked.map((u) => `${u}`).join(', ')}`);
  }
};
