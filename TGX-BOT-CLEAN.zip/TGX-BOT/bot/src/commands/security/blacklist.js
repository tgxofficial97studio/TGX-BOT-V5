const { SlashCommandBuilder } = require('discord.js');
const { update, read } = require('../../utils/store');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('blacklist')
    .setDescription('Blacklist atau unblacklist user dari bot')
    .addUserOption((o) => o.setName('user').setDescription('Target').setRequired(true))
    .addBooleanOption((o) => o.setName('status').setDescription('True untuk blacklist, false untuk hapus').setRequired(true)),
  async execute(interaction) {
    if (interaction.user.id !== process.env.OWNER_ID) {
      return interaction.reply({ content: 'Hanya owner bot yang bisa pakai command ini.', ephemeral: true });
    }
    const user = interaction.options.getUser('user');
    const status = interaction.options.getBoolean('status');
    update('blacklist', { users: [] }, (db) => {
      db.users = db.users || [];
      const has = db.users.includes(user.id);
      if (status && !has) db.users.push(user.id);
      if (!status) db.users = db.users.filter((id) => id !== user.id);
      return db;
    });
    const state = read('blacklist', { users: [] }).users.includes(user.id) ? 'diblacklist' : 'dihapus dari blacklist';
    await interaction.reply(`✅ ${user.tag} ${state}.`);
  }
};
