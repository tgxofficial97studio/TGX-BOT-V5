require('./loadEnv');
const fs = require('fs');
const path = require('path');
const { Client, Collection, GatewayIntentBits, Partials } = require('discord.js');
const loadCommands = require('./handlers/loadCommands');
const startWeb = require('./web/server');

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMembers,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.GuildMessageReactions,
    GatewayIntentBits.MessageContent
  ],
  partials: [Partials.Channel, Partials.Message, Partials.Reaction]
});

client.commands = new Collection();
loadCommands(client);

const eventDir = path.join(__dirname, 'events');
for (const file of fs.readdirSync(eventDir).filter((f) => f.endsWith('.js'))) {
  const event = require(path.join(eventDir, file));
  if (event.once) client.once(event.name, (...args) => event.execute(...args, client));
  else client.on(event.name, (...args) => event.execute(...args, client));
}

process.on('unhandledRejection', console.error);
process.on('uncaughtException', console.error);

startWeb(client);
if (!process.env.TOKEN) {
  console.error('Missing TOKEN in environment or .env file');
  process.exit(1);
}
client.login(process.env.TOKEN);
