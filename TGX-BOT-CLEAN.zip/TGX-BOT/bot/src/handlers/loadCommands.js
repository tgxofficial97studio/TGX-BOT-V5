const fs = require('fs');
const path = require('path');

function walk(dir) {
  const entries = fs.readdirSync(dir, { withFileTypes: true });
  const files = [];
  for (const entry of entries) {
    const full = path.join(dir, entry.name);
    if (entry.isDirectory()) files.push(...walk(full));
    else if (entry.isFile() && entry.name.endsWith('.js')) files.push(full);
  }
  return files;
}

module.exports = function loadCommands(client) {
  const commandRoot = path.join(__dirname, '..', 'commands');
  const files = walk(commandRoot);
  client.commands.clear();
  for (const file of files) {
    const cmd = require(file);
    if (cmd?.data?.name && typeof cmd.execute === 'function') {
      client.commands.set(cmd.data.name, cmd);
    }
  }
  return client.commands;
};
