# Discord Premium Bot V4 - Replit 24/7 Ready

Lihat `REPLIT_24X7_SETUP.md` untuk langkah publish **Reserved VM Deployment** di Replit agar bot tetap online 24/7.

# Discord Premium Replit Bot V4

Bot Discord modular untuk Replit dengan fitur yang lebih serius dan stabil dibanding V3.

## Fitur utama
- Slash command modular
- Moderation: ban, kick, timeout, untimeout, purge, lock, unlock, warn, warnings
- Utility: help, ping, avatar, userinfo, serverinfo
- Config: setwelcome, setgoodbye, setautorole, setlogchannel, automod
- Ticket system: panel, close, add, remove, transcript HTML
- Verification panel
- Reaction role panel sederhana
- Economy: balance, daily, work, pay
- Leveling: rank, leaderboard
- Fun: ship, 8ball
- Giveaway: start, end, reroll
- Anti-link dan anti-spam dasar
- Web server mini untuk menjaga repl tetap aktif dan melihat status bot

## Cara pakai di Replit
1. Buat Repl Node.js
2. Upload ZIP dan extract
3. Salin `.env.example` menjadi `.env`
4. Isi `TOKEN`, `CLIENT_ID`, dan `OWNER_ID`
5. Jalankan:
   - `npm install`
   - `npm run deploy`
   - `npm start`


## Auto restart di Replit
- Bot sekarang memakai supervisor shell sederhana: jika proses `node src/index.js` crash, Replit akan menjalankan ulang otomatis setelah 5 detik.
- Untuk menjalankan bot tanpa supervisor, pakai `npm run start:once`.
- Pengaturan ini **tidak bisa mencegah Replit tidur saat idle** pada mode hosting yang memang scale-to-zero atau workspace biasa. Agar bot benar-benar selalu online, pakai deployment yang selalu aktif seperti **Reserved VM Deployment** di Replit.

## Catatan penting
- Jika ingin slash command langsung muncul hanya di 1 server saat testing, isi `GUILD_ID`.
- Bot memakai penyimpanan JSON lokal (`src/data/*.json`) agar mudah dipakai di Replit.
- Untuk produksi besar, ganti ke MongoDB atau PostgreSQL.
- Saya sudah merapikan error handling dan validasi dasar, tetapi tidak ada software yang bisa dijamin 0 bug di semua kondisi.


## Update leveling terbaru
- XP otomatis dari chat dengan cooldown anti-spam
- `/rank` untuk lihat progress level
- `/leaderboard` untuk ranking server
- `/levelrewards` untuk lihat hadiah level
- `/claimreward` untuk ambil hadiah level yang sudah terbuka
