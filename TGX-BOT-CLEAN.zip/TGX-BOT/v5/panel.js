'use strict';

const express = require('express');

module.exports = function startV5Panel(client) {
  const app = express();
  const port = process.env.PORT || 3000;
  const startedAt = Date.now();

  function stats() {
    return {
      name: client.user ? client.user.tag : (process.env.BOT_NAME || 'TGX Bot'),
      status: client.user ? 'online' : 'starting',
      guilds: client.guilds ? client.guilds.cache.size : 0,
      users: client.guilds ? client.guilds.cache.reduce((a, g) => a + (g.memberCount || 0), 0) : 0,
      ping: client.ws ? Math.round(client.ws.ping) : 0,
      uptime: Math.floor((Date.now() - startedAt) / 1000),
      version: 'V5 Railway Premium'
    };
  }

  app.get('/healthz', (_req, res) => res.status(200).send('ok'));
  app.get('/api/status', (_req, res) => res.json(stats()));
  app.get('/', (_req, res) => {
    const s = stats();
    res.setHeader('Content-Type', 'text/html; charset=utf-8');
    res.end(`<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>TGX Bot V5 Panel</title><style>body{margin:0;font-family:Arial,Helvetica,sans-serif;background:#0b1020;color:#eef2ff}.wrap{max-width:980px;margin:0 auto;padding:36px}.hero{border:1px solid #253056;background:linear-gradient(135deg,#111936,#18244d);border-radius:24px;padding:28px;box-shadow:0 20px 60px #0007}.badge{display:inline-block;padding:8px 12px;border-radius:999px;background:#22c55e22;color:#86efac;border:1px solid #22c55e55}h1{font-size:38px;margin:18px 0 8px}.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:14px;margin-top:24px}.card{background:#0f172a;border:1px solid #253056;border-radius:18px;padding:18px}.num{font-size:28px;font-weight:800}.muted{color:#a5b4fc}.foot{margin-top:20px;color:#94a3b8;font-size:14px}</style></head><body><main class="wrap"><section class="hero"><span class="badge">${s.status.toUpperCase()} • ${s.version}</span><h1>${s.name}</h1><p class="muted">Panel web Railway aktif. Endpoint health check: <b>/healthz</b>, API status: <b>/api/status</b>.</p><div class="grid"><div class="card"><div class="num">${s.guilds}</div><div class="muted">Server</div></div><div class="card"><div class="num">${s.users}</div><div class="muted">Users</div></div><div class="card"><div class="num">${s.ping}ms</div><div class="muted">Ping</div></div><div class="card"><div class="num">${s.uptime}s</div><div class="muted">Uptime</div></div></div><p class="foot">TGX Bot V5 • anti crash • auto restart • Railway ready</p></section></main></body></html>`);
  });

  const server = app.listen(port, () => console.log(`[V5] Web panel running on port ${port}`));
  return server;
};
