'use strict';

const { spawn } = require('child_process');
const path = require('path');

const root = path.join(__dirname, '..');
const entry = process.env.BOT_ENTRY || 'bot/index.js';
const preload = path.join(__dirname, 'preload.js');
let restarts = 0;
let stopping = false;
let child = null;

function start() {
  const delay = Math.min(30000, 2000 + restarts * 3000);
  console.log(`[V5] Starting bot using ${entry}`);

  child = spawn(process.execPath, [entry], {
    cwd: root,
    stdio: 'inherit',
    env: {
      ...process.env,
      TGX_V5: 'true',
      NODE_OPTIONS: `${process.env.NODE_OPTIONS || ''} --require "${preload}"`.trim()
    }
  });

  child.on('exit', (code, signal) => {
    child = null;
    if (stopping) return;
    restarts += 1;
    console.error(`[V5] Bot stopped. code=${code} signal=${signal}. Restarting in ${delay / 1000}s...`);
    setTimeout(start, delay);
  });
}

function shutdown(signal) {
  stopping = true;
  console.log(`[V5] Received ${signal}, shutting down...`);
  if (child) child.kill(signal);
  setTimeout(() => process.exit(0), 5000).unref();
}

process.on('SIGINT', () => shutdown('SIGINT'));
process.on('SIGTERM', () => shutdown('SIGTERM'));

start();
