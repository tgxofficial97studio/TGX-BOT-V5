'use strict';

const Module = require('module');
const path = require('path');
const originalLoad = Module._load;
const root = path.join(__dirname, '..');

Module._load = function patchedLoad(request, parent, isMain) {
  const parentFile = parent && parent.filename ? parent.filename : '';
  const normalizedRequest = String(request).replace(/\\/g, '/');
  const normalizedParent = String(parentFile).replace(/\\/g, '/');

  if (normalizedRequest.endsWith('/web/server') || normalizedRequest === './web/server' || normalizedRequest === 'src/web/server') {
    return require(path.join(root, 'v5', 'panel'));
  }

  if (normalizedParent.endsWith('/src/index.js') && normalizedRequest.endsWith('/events/ready.js')) {
    return require(path.join(root, 'v5', 'ready'));
  }

  return originalLoad.apply(this, arguments);
};
