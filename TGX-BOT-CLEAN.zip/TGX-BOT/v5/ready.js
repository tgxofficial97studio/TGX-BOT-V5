'use strict';

const { ActivityType } = require('discord.js');

module.exports = {
  name: 'ready',
  once: true,
  async execute(client) {
    console.log(`[V5] Logged in as ${client.user.tag}`);
    const status = process.env.BOT_STATUS || 'online';
    const activityName = process.env.BOT_ACTIVITY || '/help | Premium V5';
    const activityTypeName = (process.env.BOT_ACTIVITY_TYPE || 'Watching').toUpperCase();
    const activityType = ActivityType[activityTypeName[0] + activityTypeName.slice(1).toLowerCase()] || ActivityType.Watching;

    try {
      client.user.setPresence({
        status,
        activities: [{ name: activityName, type: activityType }]
      });
      console.log(`[V5] Presence set: ${status} - ${activityName}`);
    } catch (err) {
      console.error('[V5] Failed to set presence:', err);
    }
  }
};
